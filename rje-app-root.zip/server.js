const express = require('express');
const app = express(),
      bodyParser = require("body-parser");
      port = 3080;

const users = [];

app.use(bodyParser.json());
//app.use(express.static(process.cwd()+"/my-app/dist/angular-nodejs-example/"));
app.use(express.static(process.cwd()+"/my-app/dist/rje-app5/"));

app.get('/api/users', (req, res) => {
  res.json(users);
});

app.post('/api/user', (req, res) => {
  const user = req.body.user;
  console.log("In ADD: " + user.lastName);
  users.push(user);
  res.json("user added");
});

app.put('/api/user', (req, res) => {
  const user = req.body.user;
  const idval = user.id;
 console.log("In EDIT");
 
  for (var i = 0; i < users.length; i++) {
    console.log("i = " + i);
    if (users[i].id === idval) {
      console.log("Id = " + i);
      users[i].firstName = user.firstName;
      users[i].lastName = user.lastName;
      users[i].team = user.team;
      users[i].job = user.job;
      users[i].status = user.status;
      console.log("new users.firstName = " + users[i].firstName);
      break;
    }
  }
  
  res.json("user updated");
});

app.delete('/api/users/:id', (req, res) => {
  console.log("In DELETE");
  const idval = req.params.id;
  
  const jreq2 = JSON.stringify(req.params);
  console.log("Delete attempt3 for " + jreq2);
  
  console.log("idval= " + idval);

  for (var i = 0; i < users.length; i++) {
    console.log("i = " + i);
    let uid = users[i].id.toString();
    console.log("useri = " + users[i].id);
    if (uid === idval) {
      console.log("Id = " + i);
      console.log("name = " + users[i].lastName);

      users.splice(i, 1);
      console.log("Item deleted");
      break;
    }

  }
    
  res.json("user deleted");
});

app.get('/', (req,res) => {
  //res.sendFile(process.cwd()+"/my-app/dist/angular-nodejs-example/index.html")
  res.sendFile(process.cwd()+"/my-app/dist/rje-app5/index.html")
});

app.listen(port, () => {
    console.log(`Server listening on the port::${port}`);
});
