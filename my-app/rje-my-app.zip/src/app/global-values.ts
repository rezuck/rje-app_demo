export class GlobalValues {
    public static currentId: number = 1;
      
    public static siteTitle: string = "Place holder";

    public static newuser: boolean = false;
}